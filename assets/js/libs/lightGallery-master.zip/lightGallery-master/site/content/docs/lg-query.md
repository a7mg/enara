---
title: 'lgQuery'
description: 'lightGallery dom manipulation utilities.'
lead: 'lightGallery provides several jQuery like utilities for dom manipulation'
date: 2020-10-06T08:48:57+00:00
draft: false
images: []
menu:
    docs:
        parent: 'API Docs'
weight: 20
toc: true
---

Need create documentation
