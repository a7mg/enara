---
title: 'Attributes'
description: 'lightGallery HTML attributes.'
lead:
    'By default, lightGallery takes all required inputs from HTML attributes,
    here you can find list of all supported HTML attributes'
date: 2020-10-06T08:48:57+00:00
draft: false
images: []
menu:
    docs:
        parent: 'API Docs'
weight: 6
toc: true
---

### Available options

{{< attributes data="true" interface="GalleryItem">}}
